(function () {
  // Street-View-style walkthrough.
  // Each scene lists "links" = arrows placed INSIDE the panorama that walk you
  // to a connected space. yaw/pitch position the arrow (radians): yaw 0 = front,
  // negative = left, positive = right; pitch positive = toward the floor.
  // arriveYaw = which way you face when you arrive. Tune these once real 360s are in.
  var SCENES = [
    { id: 'exterior', name: 'Exterior', image: 'tour/panoramas/exterior.jpg',
      links: [ { to: 'lobby', yaw: 0.0, pitch: 0.22, label: 'Enter lobby', arriveYaw: 3.14 } ] },
    { id: 'lobby', name: 'Lobby & reception', image: 'tour/panoramas/lobby.jpg',
      links: [
        { to: 'exterior', yaw: 3.14, pitch: 0.24, label: 'Step outside', arriveYaw: 0.0 },
        { to: 'deluxe',  yaw: -1.15, pitch: 0.18, label: 'Deluxe room',  arriveYaw: 3.14 },
        { to: 'premium', yaw: -0.4,  pitch: 0.18, label: 'Premium room', arriveYaw: 3.14 },
        { to: 'fourbed', yaw: 0.4,   pitch: 0.18, label: 'Family room',  arriveYaw: 3.14 },
        { to: 'hall',    yaw: 1.15,  pitch: 0.18, label: 'Function hall', arriveYaw: 3.14 }
      ] },
    { id: 'deluxe', name: 'Deluxe room', image: 'tour/panoramas/deluxe.jpg',
      links: [
        { to: 'lobby',   yaw: 3.14, pitch: 0.24, label: 'Back to lobby', arriveYaw: 0.0 },
        { to: 'balcony', yaw: 0.0,  pitch: 0.2,  label: 'Rooftop',       arriveYaw: 3.14 }
      ] },
    { id: 'premium', name: 'Premium room', image: 'tour/panoramas/premium.jpg',
      links: [ { to: 'lobby', yaw: 3.14, pitch: 0.24, label: 'Back to lobby', arriveYaw: 0.0 } ] },
    { id: 'fourbed', name: '4 bed deluxe room', image: 'tour/panoramas/fourbed.jpg',
      links: [ { to: 'lobby', yaw: 3.14, pitch: 0.24, label: 'Back to lobby', arriveYaw: 0.0 } ] },
    { id: 'hall', name: 'Function hall', image: 'tour/panoramas/hall.jpg',
      links: [ { to: 'lobby', yaw: 3.14, pitch: 0.24, label: 'Back to lobby', arriveYaw: 0.0 } ] },
    { id: 'balcony', name: 'Rooftop balcony', image: 'tour/panoramas/balcony.jpg',
      links: [ { to: 'deluxe', yaw: 3.14, pitch: 0.24, label: 'Back inside', arriveYaw: 0.0 } ] }
  ];

  var byId = {};
  SCENES.forEach(function (s) { byId[s.id] = s; });

  var panoEl = document.getElementById('pano');
  var loadingEl = document.getElementById('tourLoading');
  var errorEl = document.getElementById('tourError');
  var scenesEl = document.getElementById('tourScenes');
  var hintEl = document.getElementById('tourHint');
  var autoBtn = document.getElementById('tourAuto');
  var fullBtn = document.getElementById('tourFull');
  var stageEl = document.getElementById('tourStage');

  if (!panoEl) return;
  if (typeof Marzipano === 'undefined') {
    loadingEl.hidden = true;
    errorEl.hidden = false;
    errorEl.textContent = 'The tour viewer could not load. Please check your connection and refresh.';
    return;
  }

  var viewer = new Marzipano.Viewer(panoEl, { controls: { mouseViewMode: 'drag' } });
  var autorotate = Marzipano.autorotate({ yawSpeed: 0.03, targetPitch: 0, targetFov: Math.PI / 2 });
  var autorotateOn = true;
  var built = {};
  var currentId = null;
  var navigating = false;

  function ease(t) { return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; }
  function tween(ms, step, done) {
    var start = performance.now();
    (function frame(now) {
      var t = Math.min(1, (now - start) / ms);
      step(ease(t));
      if (t < 1) requestAnimationFrame(frame); else if (done) done();
    })(start);
  }
  function shortestAngle(a, b) {
    var d = (b - a) % (2 * Math.PI);
    if (d > Math.PI) d -= 2 * Math.PI;
    if (d < -Math.PI) d += 2 * Math.PI;
    return d;
  }

  function applyAutorotate() {
    if (autorotateOn && !navigating) {
      viewer.startMovement(autorotate);
      viewer.setIdleMovement(3000, autorotate);
    } else {
      viewer.stopMovement();
      viewer.setIdleMovement(Infinity);
    }
  }

  function makeHotspot(link) {
    var el = document.createElement('button');
    el.className = 'tour-hotspot';
    el.type = 'button';
    el.setAttribute('aria-label', link.label);
    el.innerHTML =
      '<span class="tour-hotspot-ring">' +
        '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></svg>' +
      '</span>' +
      '<span class="tour-hotspot-label">' + link.label + '</span>';
    el.addEventListener('click', function (e) { e.stopPropagation(); navigateTo(link); });
    el.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
    return el;
  }

  function buildScene(cfg, cb) {
    if (built[cfg.id]) { cb(built[cfg.id]); return; }
    var img = new Image();
    img.onload = function () {
      var w = img.naturalWidth || 4096;
      var geometry = new Marzipano.EquirectGeometry([{ width: w }]);
      var limiter = Marzipano.RectilinearView.limit.traditional(w, 100 * Math.PI / 180);
      var view = new Marzipano.RectilinearView({ yaw: 0, pitch: 0, fov: Math.PI / 2 }, limiter);
      var source = Marzipano.ImageUrlSource.fromString(cfg.image);
      var scene = viewer.createScene({ source: source, geometry: geometry, view: view });
      (cfg.links || []).forEach(function (link) {
        scene.hotspotContainer().createHotspot(makeHotspot(link), { yaw: link.yaw, pitch: link.pitch });
      });
      built[cfg.id] = { scene: scene, view: view };
      cb(built[cfg.id]);
    };
    img.onerror = function () { cb(null); };
    img.src = cfg.image;
  }

  function go(cfg, arriveYaw) {
    loadingEl.hidden = false;
    errorEl.hidden = true;
    buildScene(cfg, function (s) {
      loadingEl.hidden = true;
      if (!s) { errorEl.hidden = false; return; }
      if (typeof arriveYaw === 'number') {
        s.view.setParameters({ yaw: arriveYaw, pitch: 0, fov: Math.PI / 2 });
      }
      s.scene.switchTo({ transitionDuration: 600 });
      currentId = cfg.id;
      applyAutorotate();
      setActiveButton(cfg.id);
    });
  }

  function navigateTo(link) {
    if (navigating) return;
    var cur = built[currentId];
    if (!cur) { go(byId[link.to], link.arriveYaw); return; }
    navigating = true;
    viewer.stopMovement();
    viewer.setIdleMovement(Infinity);
    var view = cur.view;
    var startFov = view.fov();
    var endFov = Math.max(0.45, startFov * 0.5);
    var startYaw = view.yaw();
    var dYaw = shortestAngle(startYaw, link.yaw);
    var startPitch = view.pitch();
    var dPitch = link.pitch - startPitch;
    tween(440, function (e) {
      view.setParameters({
        yaw: startYaw + dYaw * e,
        pitch: startPitch + dPitch * e * 0.6,
        fov: startFov + (endFov - startFov) * e
      });
    }, function () {
      navigating = false;
      go(byId[link.to], link.arriveYaw);
      setTimeout(function () {
        view.setParameters({ yaw: link.yaw, pitch: 0, fov: Math.PI / 2 });
      }, 700);
    });
  }

  function setActiveButton(id) {
    [].forEach.call(scenesEl.children, function (btn) {
      var on = btn.dataset.id === id;
      btn.classList.toggle('active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }

  SCENES.forEach(function (cfg) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'tour-scene-btn';
    btn.textContent = cfg.name;
    btn.dataset.id = cfg.id;
    btn.setAttribute('role', 'tab');
    btn.addEventListener('click', function () { if (cfg.id !== currentId) go(cfg); });
    scenesEl.appendChild(btn);
  });

  autoBtn.addEventListener('click', function () {
    autorotateOn = !autorotateOn;
    autoBtn.classList.toggle('off', !autorotateOn);
    autoBtn.setAttribute('aria-label', autorotateOn ? 'Pause auto-rotate' : 'Start auto-rotate');
    applyAutorotate();
  });

  fullBtn.addEventListener('click', function () {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (stageEl.requestFullscreen) stageEl.requestFullscreen();
  });

  var hideHint = function () {
    if (hintEl) hintEl.classList.add('gone');
    panoEl.removeEventListener('pointerdown', hideHint);
  };
  panoEl.addEventListener('pointerdown', hideHint);
  setTimeout(hideHint, 7000);

  go(SCENES[0]);
})();
