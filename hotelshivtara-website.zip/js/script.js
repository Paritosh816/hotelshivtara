document.getElementById('year').textContent = new Date().getFullYear();

const header = document.querySelector('.site-header');
const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 40);
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

const navToggle = document.getElementById('navToggle');
const siteNav = document.getElementById('siteNav');
if (navToggle && siteNav) {
  navToggle.addEventListener('click', () => {
    const open = siteNav.classList.toggle('open');
    navToggle.classList.toggle('open', open);
    navToggle.setAttribute('aria-expanded', open);
  });
  siteNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    siteNav.classList.remove('open');
    navToggle.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  }));
}

document.querySelectorAll('.stagger').forEach(group => {
  group.querySelectorAll('.reveal').forEach((el, i) => {
    el.style.transitionDelay = (i * 110) + 'ms';
  });
});

const revealEls = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && revealEls.length) {
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -5% 0px' });
  revealEls.forEach(el => io.observe(el));
} else {
  revealEls.forEach(el => el.classList.add('in'));
}

const grid = document.getElementById('galleryGrid');
if (grid) {
  const figures = Array.from(grid.querySelectorAll('figure'));
  const buttons = document.querySelectorAll('.filter-btn');

  buttons.forEach(btn => btn.addEventListener('click', () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.filter;
    figures.forEach(fig => fig.classList.toggle('hide', f !== 'all' && fig.dataset.cat !== f));
  }));

  const lightbox = document.getElementById('lightbox');
  const lbImg = document.getElementById('lbImg');
  let current = 0;

  const visible = () => figures.filter(f => !f.classList.contains('hide'));

  function show(i) {
    const vis = visible();
    if (!vis.length) return;
    current = (i + vis.length) % vis.length;
    const img = vis[current].querySelector('img');
    lbImg.src = img.src;
    lbImg.alt = img.alt;
    lightbox.hidden = false;
    document.body.style.overflow = 'hidden';
  }
  function close() {
    lightbox.hidden = true;
    document.body.style.overflow = '';
  }

  figures.forEach(fig => fig.addEventListener('click', () => show(visible().indexOf(fig))));
  document.getElementById('lbClose').addEventListener('click', close);
  document.getElementById('lbPrev').addEventListener('click', e => { e.stopPropagation(); show(current - 1); });
  document.getElementById('lbNext').addEventListener('click', e => { e.stopPropagation(); show(current + 1); });
  lightbox.addEventListener('click', e => { if (e.target === lightbox) close(); });
  document.addEventListener('keydown', e => {
    if (lightbox.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') show(current - 1);
    if (e.key === 'ArrowRight') show(current + 1);
  });
  lightbox.hidden = true;
}
